# MongoDB Schema Design for ContextHub
## Complete Database Architecture with Indexes and Relationships

---

## 📊 Database Overview

**Database Name:** `contexthub`

**Collections:**
1. `customers` - Customer profiles and metadata
2. `conversations` - Call records and transcriptions
3. `agents` - Support agent information
4. `aisuggestions` - AI-generated suggestions and feedback
5. `knowledgebase` - Internal documentation and FAQs

---

## 1. Customers Collection

### Schema Definition

```javascript
const mongoose = require('mongoose');

const customerSchema = new mongoose.Schema({
  // Core Information
  phoneNumber: {
    type: String,
    required: true,
    unique: true,
    trim: true,
    validate: {
      validator: function(v) {
        return /^\+?\d{10,15}$/.test(v);
      },
      message: 'Invalid phone number format'
    }
  },
  
  name: {
    type: String,
    trim: true,
    index: true
  },
  
  email: {
    type: String,
    lowercase: true,
    trim: true,
    sparse: true, // Allow null but enforce uniqueness when present
    validate: {
      validator: function(v) {
        return !v || /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/.test(v);
      },
      message: 'Invalid email format'
    }
  },
  
  // Customer Status
  status: {
    type: String,
    enum: ['new', 'active', 'vip', 'churned', 'blocked'],
    default: 'new',
    index: true
  },
  
  // Tags for categorization
  tags: [{
    type: String,
    lowercase: true,
    trim: true
  }],
  
  // Customer Preferences
  preferences: {
    communicationChannel: {
      type: String,
      enum: ['phone', 'email', 'whatsapp', 'chat', 'any'],
      default: 'any'
    },
    language: {
      type: String,
      default: 'en',
      enum: ['en', 'hi', 'es', 'fr', 'de', 'ta', 'te', 'ml']
    },
    callbackTime: String, // Format: "09:00-18:00"
    timezone: {
      type: String,
      default: 'Asia/Kolkata'
    },
    doNotDisturb: {
      type: Boolean,
      default: false
    }
  },
  
  // Business Metadata
  metadata: {
    totalCalls: {
      type: Number,
      default: 0,
      min: 0
    },
    totalSpent: {
      type: Number,
      default: 0,
      min: 0
    },
    lifetimeValue: {
      type: Number,
      default: 0,
      min: 0
    },
    averageRating: {
      type: Number,
      default: 0,
      min: 0,
      max: 5
    },
    lastContactDate: Date,
    firstContactDate: Date,
    lastPurchaseDate: Date,
    nextFollowUpDate: Date
  },
  
  // Alerts and Notifications
  alerts: [{
    type: {
      type: String,
      enum: ['warning', 'info', 'critical'],
      default: 'info'
    },
    message: {
      type: String,
      required: true
    },
    createdAt: {
      type: Date,
      default: Date.now
    },
    expiresAt: Date,
    acknowledged: {
      type: Boolean,
      default: false
    }
  }],
  
  // Insights
  insights: [{
    category: String, // 'behavior', 'preference', 'pain_point'
    description: String,
    confidence: Number, // 0-1
    createdAt: {
      type: Date,
      default: Date.now
    }
  }],
  
  // Address Information
  address: {
    street: String,
    city: String,
    state: String,
    country: String,
    zipCode: String
  },
  
  // Social Links
  socialLinks: {
    linkedin: String,
    twitter: String,
    facebook: String
  },
  
  // Company Information (for B2B)
  company: {
    name: String,
    size: String,
    industry: String,
    website: String
  },
  
  // Custom Fields (flexible schema)
  customFields: {
    type: Map,
    of: mongoose.Schema.Types.Mixed
  },
  
  // Soft Delete
  isDeleted: {
    type: Boolean,
    default: false,
    index: true
  },
  
  deletedAt: Date

}, {
  timestamps: true, // Adds createdAt and updatedAt automatically
  collection: 'customers'
});

// ==================== INDEXES ====================

// Primary lookup
customerSchema.index({ phoneNumber: 1 }, { unique: true });

// Search by name
customerSchema.index({ name: 'text', email: 'text' });

// Filter by status
customerSchema.index({ status: 1, 'metadata.lastContactDate': -1 });

// Find VIP customers
customerSchema.index({ status: 1, 'metadata.lifetimeValue': -1 });

// Soft delete query optimization
customerSchema.index({ isDeleted: 1, updatedAt: -1 });

// ==================== VIRTUAL FIELDS ====================

// Full display name
customerSchema.virtual('displayName').get(function() {
  return this.name || this.phoneNumber;
});

// Customer age (days since first contact)
customerSchema.virtual('customerAge').get(function() {
  if (!this.metadata.firstContactDate) return 0;
  const diffTime = Math.abs(new Date() - this.metadata.firstContactDate);
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
});

// ==================== METHODS ====================

// Increment call count
customerSchema.methods.incrementCallCount = async function() {
  this.metadata.totalCalls += 1;
  this.metadata.lastContactDate = new Date();
  return await this.save();
};

// Add alert
customerSchema.methods.addAlert = async function(type, message, expiresAt = null) {
  this.alerts.push({ type, message, expiresAt });
  return await this.save();
};

// Calculate customer health score
customerSchema.methods.calculateHealthScore = function() {
  let score = 50; // Base score
  
  // Positive factors
  if (this.status === 'vip') score += 20;
  if (this.metadata.averageRating >= 4) score += 15;
  if (this.metadata.totalCalls > 5) score += 10;
  
  // Negative factors
  const daysSinceContact = (new Date() - this.metadata.lastContactDate) / (1000 * 60 * 60 * 24);
  if (daysSinceContact > 90) score -= 20;
  if (this.metadata.averageRating < 3) score -= 15;
  
  return Math.max(0, Math.min(100, score));
};

// ==================== STATIC METHODS ====================

// Find by phone (case-insensitive)
customerSchema.statics.findByPhone = function(phoneNumber) {
  return this.findOne({ 
    phoneNumber: phoneNumber,
    isDeleted: false 
  });
};

// Get VIP customers
customerSchema.statics.getVIPCustomers = function() {
  return this.find({ 
    status: 'vip',
    isDeleted: false 
  }).sort({ 'metadata.lifetimeValue': -1 });
};

// Get at-risk customers
customerSchema.statics.getAtRiskCustomers = function() {
  const ninetyDaysAgo = new Date();
  ninetyDaysAgo.setDate(ninetyDaysAgo.getDate() - 90);
  
  return this.find({
    'metadata.lastContactDate': { $lt: ninetyDaysAgo },
    status: { $in: ['active', 'vip'] },
    isDeleted: false
  });
};

// ==================== MIDDLEWARE ====================

// Pre-save: Set first contact date
customerSchema.pre('save', function(next) {
  if (this.isNew && !this.metadata.firstContactDate) {
    this.metadata.firstContactDate = new Date();
  }
  next();
});

// Pre-save: Clean phone number
customerSchema.pre('save', function(next) {
  if (this.phoneNumber) {
    this.phoneNumber = this.phoneNumber.replace(/[^\d+]/g, '');
  }
  next();
});

module.exports = mongoose.model('Customer', customerSchema);
```

---

## 2. Conversations Collection

### Schema Definition

```javascript
const mongoose = require('mongoose');

const conversationSchema = new mongoose.Schema({
  // References
  customerId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Customer',
    required: true,
    index: true
  },
  
  agentId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Agent',
    index: true
  },
  
  // Channel Information
  channel: {
    type: String,
    enum: ['phone', 'whatsapp', 'email', 'chat', 'sms'],
    default: 'phone',
    required: true,
    index: true
  },
  
  // Conversation Status
  status: {
    type: String,
    enum: ['active', 'completed', 'abandoned', 'transferred'],
    default: 'active',
    index: true
  },
  
  // Call-specific Details
  callDetails: {
    callSid: {
      type: String,
      unique: true,
      sparse: true,
      index: true
    },
    phoneNumber: String,
    direction: {
      type: String,
      enum: ['inbound', 'outbound']
    },
    duration: {
      type: Number, // seconds
      default: 0,
      min: 0
    },
    recordingUrl: String,
    recordingSid: String,
    startTime: Date,
    endTime: Date,
    disconnectReason: String,
    quality: {
      type: Number,
      min: 1,
      max: 5
    }
  },
  
  // Transcription Data
  transcription: [{
    speaker: {
      type: String,
      enum: ['agent', 'customer', 'system'],
      required: true
    },
    text: {
      type: String,
      required: true
    },
    timestamp: {
      type: Date,
      default: Date.now
    },
    confidence: {
      type: Number,
      min: 0,
      max: 1
    },
    language: String
  }],
  
  // AI Analysis Results
  aiAnalysis: {
    // Intent Classification
    intent: {
      type: String,
      enum: ['inquiry', 'complaint', 'request', 'feedback', 'billing', 'technical', 'general']
    },
    intentConfidence: {
      type: Number,
      min: 0,
      max: 1
    },
    
    // Sentiment Analysis
    sentiment: {
      type: String,
      enum: ['positive', 'neutral', 'negative']
    },
    sentimentScore: {
      type: Number,
      min: 0,
      max: 1
    },
    sentimentHistory: [{
      timestamp: Date,
      score: Number,
      emotion: String // happy, frustrated, angry, neutral, confused
    }],
    
    // Urgency Detection
    urgency: {
      type: String,
      enum: ['low', 'medium', 'high', 'critical'],
      default: 'medium'
    },
    
    // Topics and Entities
    topics: [String],
    keywords: [String],
    entities: {
      products: [String],
      orderNumbers: [String],
      dates: [Date],
      amounts: [Number],
      locations: [String],
      people: [String]
    },
    
    // Language Detection
    detectedLanguage: String,
    
    // Conversation Quality Metrics
    metrics: {
      avgResponseTime: Number, // seconds
      customerSpeakingTime: Number, // seconds
      agentSpeakingTime: Number,
      silenceTime: Number,
      interruptions: Number,
      talkOverInstances: Number
    }
  },
  
  // Summary and Notes
  summary: {
    auto: String, // AI-generated
    manual: String, // Agent-written
    keyPoints: [String]
  },
  
  // Resolution Information
  resolution: {
    status: {
      type: String,
      enum: ['resolved', 'pending', 'escalated', 'unresolved'],
      default: 'pending'
    },
    resolvedAt: Date,
    resolutionTime: Number, // minutes from start to resolution
    notes: String,
    nextAction: String,
    followUpDate: Date,
    escalationReason: String
  },
  
  // Associated Tickets/Issues
  tickets: [{
    ticketId: String,
    system: String, // 'internal', 'jira', 'zendesk'
    status: String,
    priority: String,
    createdAt: Date
  }],
  
  // Tags and Categories
  tags: [{
    type: String,
    lowercase: true
  }],
  
  category: String,
  subCategory: String,
  
  // Customer Satisfaction
  rating: {
    type: Number,
    min: 1,
    max: 5
  },
  feedback: String,
  npsScore: {
    type: Number,
    min: 0,
    max: 10
  },
  
  // Transfers and Escalations
  transferHistory: [{
    fromAgent: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Agent'
    },
    toAgent: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Agent'
    },
    reason: String,
    timestamp: Date
  }],
  
  // Attachments
  attachments: [{
    filename: String,
    url: String,
    type: String,
    size: Number,
    uploadedAt: Date
  }],
  
  // Quality Assurance
  qa: {
    reviewed: {
      type: Boolean,
      default: false
    },
    reviewedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Agent'
    },
    reviewedAt: Date,
    score: Number,
    comments: String
  }

}, {
  timestamps: true,
  collection: 'conversations'
});

// ==================== INDEXES ====================

// Primary lookups
conversationSchema.index({ customerId: 1, createdAt: -1 });
conversationSchema.index({ agentId: 1, createdAt: -1 });
conversationSchema.index({ 'callDetails.callSid': 1 });

// Status filtering
conversationSchema.index({ status: 1, createdAt: -1 });

// Channel filtering
conversationSchema.index({ channel: 1, createdAt: -1 });

// AI analysis queries
conversationSchema.index({ 'aiAnalysis.sentiment': 1, createdAt: -1 });
conversationSchema.index({ 'aiAnalysis.urgency': 1, status: 1 });

// Resolution status
conversationSchema.index({ 'resolution.status': 1, createdAt: -1 });

// Compound index for agent performance
conversationSchema.index({ 
  agentId: 1, 
  status: 1, 
  'resolution.status': 1,
  createdAt: -1 
});

// ==================== VIRTUAL FIELDS ====================

// Conversation duration in minutes
conversationSchema.virtual('durationInMinutes').get(function() {
  if (!this.callDetails.duration) return 0;
  return Math.round(this.callDetails.duration / 60);
});

// Is conversation active
conversationSchema.virtual('isActive').get(function() {
  return this.status === 'active';
});

// ==================== METHODS ====================

// Add transcription message
conversationSchema.methods.addTranscription = async function(speaker, text, confidence = 1.0) {
  this.transcription.push({
    speaker,
    text,
    timestamp: new Date(),
    confidence
  });
  return await this.save();
};

// Update sentiment
conversationSchema.methods.updateSentiment = async function(sentiment, score, emotion) {
  this.aiAnalysis.sentiment = sentiment;
  this.aiAnalysis.sentimentScore = score;
  this.aiAnalysis.sentimentHistory.push({
    timestamp: new Date(),
    score,
    emotion
  });
  return await this.save();
};

// Mark as resolved
conversationSchema.methods.markResolved = async function(notes) {
  this.status = 'completed';
  this.resolution.status = 'resolved';
  this.resolution.resolvedAt = new Date();
  if (notes) this.resolution.notes = notes;
  
  // Calculate resolution time
  if (this.callDetails.startTime) {
    const diff = (this.resolution.resolvedAt - this.callDetails.startTime) / 1000 / 60;
    this.resolution.resolutionTime = Math.round(diff);
  }
  
  return await this.save();
};

// ==================== STATIC METHODS ====================

// Get active conversations
conversationSchema.statics.getActive = function() {
  return this.find({ status: 'active' })
    .populate('customerId')
    .populate('agentId')
    .sort({ createdAt: -1 });
};

// Get pending resolutions
conversationSchema.statics.getPendingResolutions = function() {
  return this.find({
    status: 'completed',
    'resolution.status': 'pending'
  }).sort({ createdAt: -1 });
};

// Get average resolution time for agent
conversationSchema.statics.getAvgResolutionTime = async function(agentId) {
  const result = await this.aggregate([
    {
      $match: {
        agentId: mongoose.Types.ObjectId(agentId),
        'resolution.resolutionTime': { $exists: true, $gt: 0 }
      }
    },
    {
      $group: {
        _id: null,
        avgTime: { $avg: '$resolution.resolutionTime' }
      }
    }
  ]);
  
  return result[0]?.avgTime || 0;
};

// ==================== MIDDLEWARE ====================

// Pre-save: Auto-generate summary if transcription exists
conversationSchema.pre('save', async function(next) {
  if (this.isModified('transcription') && this.transcription.length > 5 && !this.summary.auto) {
    // Call AI to generate summary (implement this)
    // this.summary.auto = await generateSummary(this.transcription);
  }
  next();
});

// Post-save: Update customer metadata
conversationSchema.post('save', async function(doc) {
  const Customer = mongoose.model('Customer');
  await Customer.findByIdAndUpdate(doc.customerId, {
    $set: { 'metadata.lastContactDate': new Date() },
    $inc: { 'metadata.totalCalls': 1 }
  });
});

module.exports = mongoose.model('Conversation', conversationSchema);
```

---

## 3. Agents Collection

### Schema Definition

```javascript
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const agentSchema = new mongoose.Schema({
  // Basic Information
  name: {
    type: String,
    required: true,
    trim: true
  },
  
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true,
    validate: {
      validator: function(v) {
        return /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/.test(v);
      },
      message: 'Invalid email format'
    }
  },
  
  password: {
    type: String,
    required: true,
    minlength: 8,
    select: false // Don't return password by default
  },
  
  // Role and Permissions
  role: {
    type: String,
    enum: ['agent', 'supervisor', 'admin'],
    default: 'agent',
    index: true
  },
  
  permissions: [{
    type: String,
    enum: [
      'view_all_calls',
      'manage_customers',
      'manage_agents',
      'view_analytics',
      'export_data',
      'manage_settings'
    ]
  }],
  
  // Status
  status: {
    type: String,
    enum: ['online', 'offline', 'busy', 'away', 'break'],
    default: 'offline',
    index: true
  },
  
  // Contact Information
  phoneNumber: String,
  phoneExtension: String,
  
  // Organizational
  departments: [{
    type: String,
    lowercase: true
  }],
  
  skills: [{
    name: String,
    proficiency: {
      type: Number,
      min: 1,
      max: 5
    }
  }],
  
  languages: [{
    code: String, // 'en', 'hi', 'es'
    name: String,
    proficiency: String // 'native', 'fluent', 'conversational'
  }],
  
  // Performance Metrics
  performance: {
    totalCalls: {
      type: Number,
      default: 0,
      min: 0
    },
    totalMinutes: {
      type: Number,
      default: 0,
      min: 0
    },
    averageHandleTime: {
      type: Number,
      default: 0,
      min: 0
    },
    averageRating: {
      type: Number,
      default: 0,
      min: 0,
      max: 5
    },
    resolutionRate: {
      type: Number,
      default: 0,
      min: 0,
      max: 100
    },
    firstCallResolutionRate: {
      type: Number,
      default: 0,
      min: 0,
      max: 100
    },
    activeCalls: {
      type: Number,
      default: 0,
      min: 0
    },
    escalationRate: {
      type: Number,
      default: 0
    }
  },
  
  // Settings and Preferences
  settings: {
    autoAnswer: {
      type: Boolean,
      default: false
    },
    maxConcurrentCalls: {
      type: Number,
      default: 1,
      min: 1,
      max: 5
    },
    breakReminders: {
      type: Boolean,
      default: true
    },
    notificationPreferences: {
      email: { type: Boolean, default: true },
      push: { type: Boolean, default: true },
      sms: { type: Boolean, default: false }
    },
    theme: {
      type: String,
      enum: ['light', 'dark', 'auto'],
      default: 'light'
    }
  },
  
  // Availability Schedule
  schedule: [{
    day: {
      type: String,
      enum: ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday']
    },
    startTime: String, // "09:00"
    endTime: String,   // "18:00"
    isAvailable: Boolean
  }],
  
  // Session Information
  lastLogin: Date,
  lastLogout: Date,
  sessionToken: String,
  
  // Profile
  avatar: String,
  bio: String,
  
  // Achievements
  badges: [{
    name: String,
    earnedAt: Date,
    description: String
  }],
  
  // Active status
  isActive: {
    type: Boolean,
    default: true,
    index: true
  }

}, {
  timestamps: true,
  collection: 'agents'
});

// ==================== INDEXES ====================

agentSchema.index({ email: 1 }, { unique: true });
agentSchema.index({ status: 1, isActive: 1 });
agentSchema.index({ role: 1, isActive: 1 });
agentSchema.index({ departments: 1 });

// ==================== METHODS ====================

// Compare password
agentSchema.methods.comparePassword = async function(candidatePassword) {
  return await bcrypt.compare(candidatePassword, this.password);
};

// Generate auth token (implement JWT)
agentSchema.methods.generateAuthToken = function() {
  // Implement JWT token generation
  return 'jwt_token_here';
};

// Update performance metrics
agentSchema.methods.updatePerformance = async function(metrics) {
  Object.assign(this.performance, metrics);
  return await this.save();
};

// ==================== MIDDLEWARE ====================

// Hash password before saving
agentSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 12);
  next();
});

module.exports = mongoose.model('Agent', agentSchema);
```

---

## 4. AI Suggestions Collection

```javascript
const mongoose = require('mongoose');

const aiSuggestionSchema = new mongoose.Schema({
  conversationId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Conversation',
    required: true,
    index: true
  },
  
  timestamp: {
    type: Date,
    default: Date.now
  },
  
  context: {
    lastMessages: [String],
    customerIntent: String,
    conversationPhase: {
      type: String,
      enum: ['greeting', 'problem', 'solution', 'closing']
    }
  },
  
  suggestions: [{
    type: {
      type: String,
      enum: ['response', 'action', 'knowledge', 'escalation']
    },
    text: String,
    confidence: {
      type: Number,
      min: 0,
      max: 1
    },
    relevance: {
      type: Number,
      min: 0,
      max: 1
    },
    source: String
  }],
  
  agentAction: {
    used: {
      type: Boolean,
      default: false
    },
    selectedIndex: Number,
    modifiedText: String,
    feedback: {
      type: String,
      enum: ['helpful', 'not-helpful', 'partially-helpful']
    },
    feedbackComment: String
  }

}, {
  timestamps: true,
  collection: 'aisuggestions'
});

aiSuggestionSchema.index({ conversationId: 1, timestamp: -1 });

module.exports = mongoose.model('AISuggestion', aiSuggestionSchema);
```

---

## 5. Knowledge Base Collection

```javascript
const mongoose = require('mongoose');

const knowledgeBaseSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    index: true
  },
  
  category: {
    type: String,
    required: true,
    index: true
  },
  
  tags: [String],
  
  content: {
    question: String,
    answer: {
      type: String,
      required: true
    },
    macros: [String], // Pre-written responses
    relatedArticles: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'KnowledgeBase'
    }]
  },
  
  metadata: {
    timesUsed: {
      type: Number,
      default: 0
    },
    timesHelpful: {
      type: Number,
      default: 0
    },
    averageRating: {
      type: Number,
      default: 0
    },
    lastUpdated: Date,
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Agent'
    }
  },
  
  searchVector: [Number], // For semantic search
  
  isPublished: {
    type: Boolean,
    default: true
  }

}, {
  timestamps: true,
  collection: 'knowledgebase'
});

knowledgeBaseSchema.index({ title: 'text', 'content.answer': 'text' });
knowledgeBaseSchema.index({ category: 1, isPublished: 1 });

module.exports = mongoose.model('KnowledgeBase', knowledgeBaseSchema);
```

---

## 📊 Aggregation Pipelines (Analytics Queries)

### 1. Agent Performance Dashboard
```javascript
db.conversations.aggregate([
  {
    $match: {
      agentId: ObjectId("agent_id_here"),
      createdAt: {
        $gte: ISODate("2026-01-01"),
        $lte: ISODate("2026-01-31")
      }
    }
  },
  {
    $group: {
      _id: "$agentId",
      totalCalls: { $sum: 1 },
      avgDuration: { $avg: "$callDetails.duration" },
      avgRating: { $avg: "$rating" },
      resolvedCount: {
        $sum: { $cond: [{ $eq: ["$resolution.status", "resolved"] }, 1, 0] }
      }
    }
  },
  {
    $project: {
      totalCalls: 1,
      avgDuration: { $round: ["$avgDuration", 0] },
      avgRating: { $round: ["$avgRating", 2] },
      resolutionRate: {
        $multiply: [
          { $divide: ["$resolvedCount", "$totalCalls"] },
          100
        ]
      }
    }
  }
]);
```

### 2. Customer Sentiment Trends
```javascript
db.conversations.aggregate([
  {
    $match: {
      customerId: ObjectId("customer_id_here")
    }
  },
  {
    $unwind: "$aiAnalysis.sentimentHistory"
  },
  {
    $group: {
      _id: {
        $dateToString: {
          format: "%Y-%m-%d",
          date: "$aiAnalysis.sentimentHistory.timestamp"
        }
      },
      avgSentiment: { $avg: "$aiAnalysis.sentimentHistory.score" },
      emotions: { $push: "$aiAnalysis.sentimentHistory.emotion" }
    }
  },
  {
    $sort: { _id: 1 }
  }
]);
```

### 3. Top Issues by Category
```javascript
db.conversations.aggregate([
  {
    $match: {
      createdAt: { $gte: ISODate("2026-01-01") }
    }
  },
  {
    $group: {
      _id: "$aiAnalysis.intent",
      count: { $sum: 1 },
      avgResolutionTime: { $avg: "$resolution.resolutionTime" }
    }
  },
  {
    $sort: { count: -1 }
  },
  {
    $limit: 10
  }
]);
```

---

## 🔐 Security Considerations

1. **Password Hashing**: Always hash passwords with bcrypt (salt rounds: 12)
2. **API Keys**: Never store API keys in database - use environment variables
3. **PII Encryption**: Consider encrypting sensitive customer data at rest
4. **Access Control**: Implement role-based access control (RBAC)
5. **Audit Logs**: Track all data modifications with timestamps and user IDs

---

## 🚀 Performance Optimization

1. **Compound Indexes**: Create for frequently combined queries
2. **Partial Indexes**: Use for filtered queries (e.g., `isDeleted: false`)
3. **Text Indexes**: For search functionality
4. **Geospatial Indexes**: If adding location-based features
5. **Capped Collections**: For logs (auto-delete old entries)
6. **TTL Indexes**: For automatic document expiration

---

## 📈 Monitoring Queries

```javascript
// Check collection sizes
db.stats()

// Analyze index usage
db.conversations.aggregate([{ $indexStats: {} }])

// Find slow queries
db.system.profile.find({ millis: { $gt: 100 } }).sort({ millis: -1 })
```

---

## END OF MONGODB SCHEMA DOCUMENTATION